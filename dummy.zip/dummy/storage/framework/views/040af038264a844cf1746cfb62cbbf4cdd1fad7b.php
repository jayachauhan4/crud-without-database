<?php echo $__env->make('categories.modals.create', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?> 
 <?php echo $__env->make('categories.modals.edit', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>  
<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="csrf-token" content="<?php echo e(csrf_token()); ?>">
    <link rel="stylesheet" href="https://stackpath.bootstrapcdn.com/bootstrap/4.5.2/css/bootstrap.min.css" >
</head>
<body>
    <div class="container mt-2">
        <div class="row">
            <div class="col-lg-12 margin-tb">
                
                <div class="pull-left mb-2">
                <a class="btn btn-primary" href="<?php echo e(route('blogs.index')); ?>" enctype="multipart/form-data">
                        Back</a></div>
                        <div class="pull-right mb-2">
                <a href='#' class="btn btn-primary" data-bs-toggle="modal" data-bs-target="#createCategoryModal"> Create Category</a> 
</div>    
            </div>
            </div>
        </div>
        
        <table class="table table-bordered">
            <thead>
                <tr>
                    <th>S.No</th>
                    <th>Category Name</th>
                    <th>Category Slug</th>
                    <th width="280px">Action</th>
                </tr>
            </thead>
            <tbody>
                <?php $__currentLoopData = $categories; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $category): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                    <tr>
                        <td><?php echo e($category->id); ?></td>
                        <td><?php echo e($category->name); ?></td>
                        <td><?php echo e($category->slug); ?></td>
                        
                        <td>
                            <form action="<?php echo e(route('categories.destroy',$category->id)); ?>" method="Post">
                                  <button class="btn btn-primary edit" type="button"  data-bs-toggle="modal"  value="<?php echo e($category->id); ?>" >Edit</button> 
                                <?php echo csrf_field(); ?>
                                <?php echo method_field('DELETE'); ?>
                                <button type="submit" class="btn btn-danger">Delete</button>
                            </form>
                        </td>
                    </tr>
                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
            </tbody>
        </table>
        
    </div>


<!-- modal edit -->




    
</body>
<script>
     //debugger;
     $(document).on('click','.edit',function(){
        var id= $(this).val();
        //console.log(id);
        $('#editCategoryModal').modal('show');
        $.ajax({
       url: "category/"+id,
       type: "GET",
       success: function(response) {
        //console.log(response.category);
        
        $("#name").val(response.category.name);
        $("#slug").val(response.category.slug);
                
       }
        });
       
    $(document).on('submit','#categoryeditForm',function(e){
      e.preventDefault();
      //var id= $("#id").val();
       // console.log(id);
      let name = $('#name').val();
    let slug = $('#slug').val();
    
    
    //let message = $('#InputMessage').val();
       let formData = new FormData($('#categoryeditForm')[0]);
       $.ajax({
       url: "/cat/"+id,
       headers:{
         'X-CSRF-TOKEN': $('meta[name="csrf-token"]').attr('content')
              },
          type: "POST",
          data: formData,
          contentType:false,
          processData:false,
          success: function(response) {
       console.log(response);
$('#submit').html('Submit');
 $("#submit"). attr("disabled", false);
 $('#successMsg').show();
 setTimeout(function(){$('#editCategoryModal').modal('hide');},10000);
 //$('#createCategoryModal').modal('hide');
 window.location.reload();
 
 
 document.getElementById("categoryeditForm").reset(); 
 setTimeout(function(){
            $('#successMsg').hide();
            $('#msg_div').hide();
            
            },2000);
 },
 error: function(response) {
        $('#nameErrorMsg').text(response.responseJSON.errors.name);
        $('#slugErrorMsg').text(response.responseJSON.errors.slug);
       
        //$('#messageErrorMsg').text(response.responseJSON.errors.message);
      },
});

       
   });
})




</script>
</html><?php /**PATH C:\xampp\htdocs\Blog_crud\resources\views/categories/index.blade.php ENDPATH**/ ?>