
<!--create blog modal-->
    <div class="modal fade" id="blogModal" tabindex="-1" aria-labelledby="exampleModalLabel" aria-hidden="true">
  <div class="modal-dialog">
    <div class="modal-content">
    <div class="container mt-2">
        <div class="row">
            <div class="col-lg-12 margin-tb">
                <div class="pull-left mb-2">
                    <h2>Add Blog</h2>
                </div>
                <div class="pull-right">
                    <a class="btn btn-primary" href="<?php echo e(URL('/')); ?>"> Back</a>
                </div>
            </div>
        </div>
        

      
       
<form   >
<div class="row">

    
    
            <div class="col-xs-12 col-sm-12 col-md-12">
                    <div class="form-group">
                        <strong> Name:</strong>
                        <input type="text" minlength="6"  id="name" name="name" required  class="form-control"  placeholder="Blog Name">
                        <span class="text-danger" id="nameErrorMsg"></span>
                     </div>
            </div>
             <div class="col-xs-12 col-sm-12 col-md-12">
                    <div class="form-group">
                        <strong>Slug:</strong>
                        <input type="text" minlength="6"  id="slug" name="slug" required class="form-control" placeholder="Enter Slug">
                        <span class="text-danger" id="slugErrorMsg"></span>
                    </div>
            </div>
            <div class="col-xs-12 col-sm-12 col-md-12">
                    <div class="form-group">
                        <strong>Image:</strong>
                        <input type="file"  id="image" accept="image/*" required  name="image" class="form-control" placeholder="upload image">
                        <span class="text-danger" id="imageErrorMsg"></span>
                    </div>
            </div> 
            <!-- <div class="col-xs-12 col-sm-12 col-md-12">
                    <div class="form-group">
                        <strong>Image:</strong>
                        <input type="file"  id="im" accept="image/*" required  name="image" class="form-control" placeholder="upload image">
                        <span class="text-danger" id="imageErrorMsg"></span>
                    </div>
            </div>  -->
            <div class="col-xs-12 col-sm-12 col-md-12">
                    <div class="form-group">
                        <strong>Description:</strong>
                        <input type="text" minlength="20" maxlength="200"  id="description" required  name="description" class="form-control" placeholder="Enter Description">
                        <span class="text-danger" id="descriptionErrorMsg"></span>
                    </div>
            </div>
            <div class="col-xs-12 col-sm-12 col-md-12">
                    <div class="form-group">
                        <strong>Category:</strong>
                        <select name="category_id" class="form-control cat" id="category">
                        
                                    
                                  
                                </select>
                               
                                <span class="text-danger" id="categoryErrorMsg"></span>
                        
                    </div>
                </div> 
            <div class="container_btn">
               <div class="center_btn">
               <button  class="btn btn-primary httpbin" onclick="add()">Save</button>
               </div>
            </div>
    
</div>

    </form>
    <div  class="alert alert-success " id="msg"></div>
<div  class="alert alert-danger " id="msg-danger"></div>    
</div>
</div>
       
       
    </div>
</div>
</div>
</div>
<?php /**PATH C:\xampp\htdocs\dummy\resources\views/blogs/modals/create.blade.php ENDPATH**/ ?>