 <!DOCTYPE html>
<html lang="<?php echo e(str_replace('_', '-', app()->getLocale())); ?>">
    <head>
    <title>Blog</title>
    <meta name="csrf-token" content="<?php echo e(csrf_token()); ?>">
    <link rel="stylesheet" href="https://stackpath.bootstrapcdn.com/bootstrap/4.5.2/css/bootstrap.min.css" >
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.0.2/dist/css/bootstrap.min.css" rel="stylesheet">
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/4.7.0/css/font-awesome.min.css">
    <script src="https://cdn.jsdelivr.net/npm/bootstrap@5.0.2/dist/js/bootstrap.bundle.min.js" integrity="sha384-MrcW6ZMFYlzcLA8Nl+NtUVF0sA7MsXsP1UyJoMp4YLEuNSfAP+JcXn/tWtIaxVXM" crossorigin="anonymous"></script>
    <script src="https://cdnjs.cloudflare.com/ajax/libs/jquery/3.6.0/jquery.min.js" ></script>

        <style>
          .category{height:300px;}
          .container_btn{
  position: relative;
}
.center_btn{
  margin: 0;
  width:100%;
}
         </style>   

</head>
<body>
<div class="modal fade" id="editCategoryModal" tabindex="-1" aria-labelledby="exampleModalLabel" aria-hidden="true">
  <div class="modal-dialog">
    <div class="modal-content category">
    <div class="container mt-2">
        <div class="row">
            <div class="col-lg-12 margin-tb">
                <div class="pull-left">
                    <h2>Edit Blog</h2>
                </div>
                <div class="pull-right">
                    <a class="btn btn-primary" href="<?php echo e(route('categories.index')); ?>" enctype="multipart/form-data">
                        Back</a>
                </div>
            </div>
        </div>
        <div class="alert alert-success" role="alert" id="successMsg" style="display: none" >
  Category updated successfully 
</div>
        <form action="url('cat/'.$categories->id)"  id="categoryeditForm" method="POST" enctype="multipart/form-data">
            <?php echo csrf_field(); ?>
            
            
            <input type="hidden" id="id" value="" name="id"/>
            <div class="row">
                <div class="col-xs-12 col-sm-12 col-md-12">
                
                    <div class="form-group">
                        <strong>Category Name:</strong>
                        <input type="text" name="name" id="name" value="" class="form-control"
                            placeholder="Enter Category name">
                            <span class="text-danger" id="nameErrorMsg"></span>
                    </div>
                </div>
                <div class="col-xs-12 col-sm-12 col-md-12">
                    <div class="form-group">
                        <strong>Slug:</strong>
                        <input type="text" name="slug" id="slug" class="form-control" placeholder="Enter Slug"
                            value="">
                            <span class="text-danger" id="slugErrorMsg"></span>
                    </div>
                </div>
                
               
                <div class="container_btn">
  <div class="center_btn">
                <button type="submit" id="submit" style="width:100%;" class="btn btn-primary ">Submit</button>
</div>
</div>
            </div>
        </form>
    </div>
</div>
</div>
</div>
</body>
<script>
     //debugger;
// $(document).ready(function(){
//     $(document).on('click','.edit',function(){
//         var id= $(this).val();
        
//         $('#editCategoryModal').modal('show');
//         $.ajax({
//        url: "/categories/modals/edit/"+id,
//        type: "GET",
//        success: function( response ) {
//         //console.log(name);
        
//         $("#name").val(response.category.name);
//         $("#slug").val(response.category.slug);
        
//        }
//         });
//     }
//     )});
    </script>
</html> <?php /**PATH C:\xampp\htdocs\Blog_crud\resources\views/categories/modals/edit.blade.php ENDPATH**/ ?>