
<?php $__env->startSection('content'); ?>
<div class="pull-left mb-2" >
                <a class="btn btn-primary" href="<?php echo e(url('/')); ?>" >
                        Back</a></div>
                        <div class="pull-right mb-2">
                <a href='#' class="btn btn-primary" data-bs-toggle="modal" data-bs-target="#createCategoryModal"> Create Category</a> 
</div>    
        
        </div>
        <div class="container"  >
        
        <table class="table table-bordered" > <thead><tr> <th>Category Name</th> <th>Category Slug</th><th width="280px">Action</th></tr></thead><tbody id="table"></tbody></table>
                
                    
                   
                   
                    
                
            
            
               
                    
                        
                        
                        
                        
                        
                            
                       
                   
                    
           
        
</div>
    

    <?php $__env->stopSection(); ?>
<!-- modal edit -->




    

<?php echo $__env->make('layouts.appcat', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp\htdocs\dummy\resources\views/categories/index.blade.php ENDPATH**/ ?>