<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <link rel="stylesheet" href="https://stackpath.bootstrapcdn.com/bootstrap/4.5.2/css/bootstrap.min.css" >
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.0.2/dist/css/bootstrap.min.css" rel="stylesheet">
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/4.7.0/css/font-awesome.min.css">
    <script src="https://cdn.jsdelivr.net/npm/bootstrap@5.0.2/dist/js/bootstrap.bundle.min.js" integrity="sha384-MrcW6ZMFYlzcLA8Nl+NtUVF0sA7MsXsP1UyJoMp4YLEuNSfAP+JcXn/tWtIaxVXM" crossorigin="anonymous"></script>
    <script src="https://cdnjs.cloudflare.com/ajax/libs/jquery/3.6.0/jquery.min.js" ></script>
    <link rel="stylesheet" href="https://stackpath.bootstrapcdn.com/bootstrap/4.5.2/css/bootstrap.min.css">
    <!-- <link rel="stylesheet" href="https://stackpath.bootstrapcdn.com/bootstrap/4.5.2/css/bootstrap.min.css" > -->
    
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/4.7.0/css/font-awesome.min.css">

</head>
<body>
    

<div class="modal fade" id="editBlogModal" tabindex="-1" aria-labelledby="exampleModalLabel" aria-hidden="true">
  <div class="modal-dialog">
    <div class="modal-content">

    <div class="container mt-2">
        <div class="row">
            <div class="col-lg-12 margin-tb">
            <div class="pull-left">
                    <h2>Edit Blog</h2>
            </div>
            <div class="pull-right">
                    <a class="btn btn-primary" href="{{ route('blogs.index') }}" enctype="multipart/form-data">
                        Back</a>
            </div>
        </div>
    </div>
    

    <form >
    <div class="row">
            

            <div class="col-xs-12 col-sm-12 col-md-12">
                    <div class="form-group">
                        <strong>Blog Name:</strong>
                        <input type="text" required name="Inputname" id="Inputname"  class="form-control"
                            placeholder="Enter Blog name" >
                            <span class="text-danger" id="nameErrorMsg"></span>
                    </div>
            </div>
            <div class="col-xs-12 col-sm-12 col-md-12">
                    <div class="form-group">
                        <strong>Slug:</strong>
                        <input type="text" name="slug" required id="Inputslug"  class="form-control" placeholder="Enter Slug"
                            >
                            <span class="text-danger" id="slugErrorMsg"></span>
                    </div>
            </div>

            <div class="col-xs-12 col-sm-12 col-md-12">
                    <div class="form-group" id="showim">
                        <strong>Image:</strong>
                        <div id="show"></div>
                        <input type="file" name="Inputimage"  accept="image/*" id="Inputimage"  class="form-control"
                            placeholder="Upload Image">
                            <span class="text-danger" id="imageErrorMsg"></span>
                    </div>
                </div> 
                <div class="col-xs-12 col-sm-12 col-md-12">
                    <div class="form-group">
                        <strong>Description:</strong>
                        <input type="text" name="Inputdescription" required id="Inputdescription"  class="form-control"
                            placeholder="Enter Description">
                            <span class="text-danger" id="descriptionErrorMsg"></span>
                    </div>
                </div>

                <div class="col-xs-12 col-sm-12 col-md-12">
                    <div class="form-group">
                        <strong>Category:</strong>
                        <select name="category_id" class="form-control" id="inputcategory">
                        
                                    
                                  
                                </select>
                               
                                <span class="text-danger" id="categoryErrorMsg"></span>
                        
                    </div>
                </div> 
                <div class="center_btn">
                <button  onclick="updateData()" style="width:100%;"  class="btn btn-primary  httpbin">Update</button>
</div>
            </div>
</form>

<div class="alert alert-success"  id="msg"></div>
            <div  class="alert alert-danger" id="msg-danger"></div>
</div>

</div>
</div>
</div>

</body>
<script>


</script>
</html>