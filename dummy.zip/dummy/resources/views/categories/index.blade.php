@extends('layouts.appcat')
@section('content')
<div class="pull-left mb-2" >
                <a class="btn btn-primary" href="{{ url('/') }}" >
                        Back</a></div>
                        <div class="pull-right mb-2">
                <a href='#' class="btn btn-primary" data-bs-toggle="modal" data-bs-target="#createCategoryModal"> Create Category</a> 
</div>    
        
        </div>
        <div class="container"  >
        
        <table class="table table-bordered" > <thead><tr> <th>Category Name</th> <th>Category Slug</th><th width="280px">Action</th></tr></thead><tbody id="table"></tbody></table>
                
                    
                   
                   
                    
                
            
            
               
                    
                        
                        
                        
                        
                        
                            
                       
                   
                    
           
        
</div>
    

    @endsection
<!-- modal edit -->




    
