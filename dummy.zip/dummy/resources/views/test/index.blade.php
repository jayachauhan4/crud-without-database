<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Document</title>
</head>
<body>
<div class="container">
    <div class="col-sm-offset-0 col-sm-12 ">
        <div class="panel panel-default">
            <div id="header" class="panel-heading">
                <h4><i class="fa fa-btn fa-users"></i>Test</h4>
            </div>

            <div class="panel-body">

                <form action="{{ route('test.post') }}" method="POST">
                    @csrf() 
                    @if(isset($text))
                    <input type="text" name="text" value="{{ $text }}">                                      
                    @else
                    <input type="text" name="text" >                                      
                    @endif
                    <input type="submit">
                </form>
            </div>
        </div>
    </div>
</div>

<form action="{{ route('test.post') }}" enctype="multipart/form-data" id="blogForm" method="POST">
                    @csrf() 
                    <!-- @if(isset($text)) -->
                    <input type="text"  name="text" value="{{ $text }}">                                      
                    <!-- @else -->
                    <input type="text" name="text" >                                      
                    <!-- @endif -->
                    <input type="submit">
                </form>

                <h2 class="article-title">{{ $text }}</h2>
</body>
</html>