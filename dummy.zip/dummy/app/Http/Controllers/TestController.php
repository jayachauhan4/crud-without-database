<?php

namespace App\Http\Controllers;

use Illuminate\Http\Request;

class TestController extends Controller
{
    public function form(Request $request) {
        // if ($request->isMethod('get')) {
        //     echo 'REQUEST GET';                      
        //     return view('test.index');  
        // }
        
        // if ($request->isMethod('post')) {
            $text = $request->input('text');
            echo 'REQUEST POST';
            echo '<br>';
            echo $text; 
            //dd($text); 
            return view('test.index', ['text' => $text]);
        //}
    }
    
}
